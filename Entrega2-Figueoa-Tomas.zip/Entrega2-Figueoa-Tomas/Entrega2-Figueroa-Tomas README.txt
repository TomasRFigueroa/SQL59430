Este archivo SQL se utiliza para crear y gestionar una base de datos llamada "SolidaridadActiva". La base de datos está diseñada para gestionar la información de los voluntarios, beneficiarios, actividades, donaciones y recursos en una organización de ayuda humanitaria. A continuación, se describen los objetos de la base de datos:

Tablas
Voluntarios: Almacena la información de los voluntarios, como nombre, teléfono, correo electrónico, fecha de ingreso y estado (activo o inactivo).
Beneficiarios: Contiene los datos de las personas que reciben ayuda, como nombre, dirección, teléfono y las necesidades que tienen.
CategoriasActividades: Define las categorías para clasificar las actividades realizadas por los voluntarios.
Actividades: Registra las actividades realizadas por los voluntarios, incluyendo una descripción, fecha, lugar y la categoría asociada.
Donaciones: Registra las donaciones realizadas por los voluntarios, incluyendo monto, fecha y una breve descripción.
Recursos: Almacena información sobre los recursos disponibles, como cantidad y fecha de ingreso.
Participaciones: Registra las participaciones de los voluntarios en las actividades realizadas.
Índices
idx_monto_donaciones: Optimiza las consultas que busquen por el monto de las donaciones.
idx_fecha_actividades: Optimiza las consultas que busquen por la fecha de las actividades.
Procedimientos Almacenados (Stored Procedures)
AgregarVoluntario: Permite agregar un nuevo voluntario a la base de datos.
RegistrarDonacion: Permite registrar una nueva donación realizada por un voluntario.
RegistrarParticipacion: Registra la participación de un voluntario en una actividad.
ObtenerVoluntariosActivos: Devuelve una lista de los voluntarios que están activos.
Triggers
trg_baja_voluntario: Actualiza la fecha de baja de un voluntario cuando su estado cambia a "Inactivo".
trg_no_eliminar_beneficiario: Previene la eliminación de un beneficiario si tiene actividades asociadas.
Vistas
Vista_VoluntariosActivos: Muestra los datos de los voluntarios que están activos.
Vista_BeneficiariosConActividades: Muestra los beneficiarios junto con las actividades en las que están involucrados.
Vista_DonacionesPorVoluntario: Muestra las donaciones realizadas por cada voluntario.
Funciones
ObtenerTotalDonaciones: Devuelve la suma total de las donaciones realizadas en el sistema.
ObtenerParticipacionesPorVoluntario: Devuelve el número total de participaciones realizadas por un voluntario específico.
Proceso de Inserción de Datos
Los datos pueden ser insertados mediante importación o mediante scripts de inserción utilizando los procedimientos almacenados disponibles.

